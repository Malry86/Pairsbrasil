gdjs.NewSceneCode = {};
gdjs.NewSceneCode.forEachCount0_5 = 0;

gdjs.NewSceneCode.forEachCount1_5 = 0;

gdjs.NewSceneCode.forEachCount2_5 = 0;

gdjs.NewSceneCode.forEachCount3_5 = 0;

gdjs.NewSceneCode.forEachCount4_5 = 0;

gdjs.NewSceneCode.forEachCount5_5 = 0;

gdjs.NewSceneCode.forEachCount6_5 = 0;

gdjs.NewSceneCode.forEachCount7_5 = 0;

gdjs.NewSceneCode.forEachIndex3 = 0;

gdjs.NewSceneCode.forEachIndex5 = 0;

gdjs.NewSceneCode.forEachObjects3 = [];

gdjs.NewSceneCode.forEachObjects5 = [];

gdjs.NewSceneCode.forEachTemporary3 = null;

gdjs.NewSceneCode.forEachTotalCount3 = 0;

gdjs.NewSceneCode.forEachTotalCount5 = 0;

gdjs.NewSceneCode.GDcard_95wedObjects1= [];
gdjs.NewSceneCode.GDcard_95wedObjects2= [];
gdjs.NewSceneCode.GDcard_95wedObjects3= [];
gdjs.NewSceneCode.GDcard_95wedObjects4= [];
gdjs.NewSceneCode.GDcard_95wedObjects5= [];
gdjs.NewSceneCode.GDcard_95wedObjects6= [];
gdjs.NewSceneCode.GDcard_95wedObjects7= [];
gdjs.NewSceneCode.GDcard_95satObjects1= [];
gdjs.NewSceneCode.GDcard_95satObjects2= [];
gdjs.NewSceneCode.GDcard_95satObjects3= [];
gdjs.NewSceneCode.GDcard_95satObjects4= [];
gdjs.NewSceneCode.GDcard_95satObjects5= [];
gdjs.NewSceneCode.GDcard_95satObjects6= [];
gdjs.NewSceneCode.GDcard_95satObjects7= [];
gdjs.NewSceneCode.GDcard_95weekObjects1= [];
gdjs.NewSceneCode.GDcard_95weekObjects2= [];
gdjs.NewSceneCode.GDcard_95weekObjects3= [];
gdjs.NewSceneCode.GDcard_95weekObjects4= [];
gdjs.NewSceneCode.GDcard_95weekObjects5= [];
gdjs.NewSceneCode.GDcard_95weekObjects6= [];
gdjs.NewSceneCode.GDcard_95weekObjects7= [];
gdjs.NewSceneCode.GDcard_95friObjects1= [];
gdjs.NewSceneCode.GDcard_95friObjects2= [];
gdjs.NewSceneCode.GDcard_95friObjects3= [];
gdjs.NewSceneCode.GDcard_95friObjects4= [];
gdjs.NewSceneCode.GDcard_95friObjects5= [];
gdjs.NewSceneCode.GDcard_95friObjects6= [];
gdjs.NewSceneCode.GDcard_95friObjects7= [];
gdjs.NewSceneCode.GDcard_95tueObjects1= [];
gdjs.NewSceneCode.GDcard_95tueObjects2= [];
gdjs.NewSceneCode.GDcard_95tueObjects3= [];
gdjs.NewSceneCode.GDcard_95tueObjects4= [];
gdjs.NewSceneCode.GDcard_95tueObjects5= [];
gdjs.NewSceneCode.GDcard_95tueObjects6= [];
gdjs.NewSceneCode.GDcard_95tueObjects7= [];
gdjs.NewSceneCode.GDcard_95sunObjects1= [];
gdjs.NewSceneCode.GDcard_95sunObjects2= [];
gdjs.NewSceneCode.GDcard_95sunObjects3= [];
gdjs.NewSceneCode.GDcard_95sunObjects4= [];
gdjs.NewSceneCode.GDcard_95sunObjects5= [];
gdjs.NewSceneCode.GDcard_95sunObjects6= [];
gdjs.NewSceneCode.GDcard_95sunObjects7= [];
gdjs.NewSceneCode.GDcard_95thurObjects1= [];
gdjs.NewSceneCode.GDcard_95thurObjects2= [];
gdjs.NewSceneCode.GDcard_95thurObjects3= [];
gdjs.NewSceneCode.GDcard_95thurObjects4= [];
gdjs.NewSceneCode.GDcard_95thurObjects5= [];
gdjs.NewSceneCode.GDcard_95thurObjects6= [];
gdjs.NewSceneCode.GDcard_95thurObjects7= [];
gdjs.NewSceneCode.GDcard_95monObjects1= [];
gdjs.NewSceneCode.GDcard_95monObjects2= [];
gdjs.NewSceneCode.GDcard_95monObjects3= [];
gdjs.NewSceneCode.GDcard_95monObjects4= [];
gdjs.NewSceneCode.GDcard_95monObjects5= [];
gdjs.NewSceneCode.GDcard_95monObjects6= [];
gdjs.NewSceneCode.GDcard_95monObjects7= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects1= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects2= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects3= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects4= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects5= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects6= [];
gdjs.NewSceneCode.GDposition_95placeholderObjects7= [];
gdjs.NewSceneCode.GDbuttonObjects1= [];
gdjs.NewSceneCode.GDbuttonObjects2= [];
gdjs.NewSceneCode.GDbuttonObjects3= [];
gdjs.NewSceneCode.GDbuttonObjects4= [];
gdjs.NewSceneCode.GDbuttonObjects5= [];
gdjs.NewSceneCode.GDbuttonObjects6= [];
gdjs.NewSceneCode.GDbuttonObjects7= [];
gdjs.NewSceneCode.GDboardObjects1= [];
gdjs.NewSceneCode.GDboardObjects2= [];
gdjs.NewSceneCode.GDboardObjects3= [];
gdjs.NewSceneCode.GDboardObjects4= [];
gdjs.NewSceneCode.GDboardObjects5= [];
gdjs.NewSceneCode.GDboardObjects6= [];
gdjs.NewSceneCode.GDboardObjects7= [];
gdjs.NewSceneCode.GDbackgroundObjects1= [];
gdjs.NewSceneCode.GDbackgroundObjects2= [];
gdjs.NewSceneCode.GDbackgroundObjects3= [];
gdjs.NewSceneCode.GDbackgroundObjects4= [];
gdjs.NewSceneCode.GDbackgroundObjects5= [];
gdjs.NewSceneCode.GDbackgroundObjects6= [];
gdjs.NewSceneCode.GDbackgroundObjects7= [];
gdjs.NewSceneCode.GDpairsObjects1= [];
gdjs.NewSceneCode.GDpairsObjects2= [];
gdjs.NewSceneCode.GDpairsObjects3= [];
gdjs.NewSceneCode.GDpairsObjects4= [];
gdjs.NewSceneCode.GDpairsObjects5= [];
gdjs.NewSceneCode.GDpairsObjects6= [];
gdjs.NewSceneCode.GDpairsObjects7= [];
gdjs.NewSceneCode.GDstar_95particleObjects1= [];
gdjs.NewSceneCode.GDstar_95particleObjects2= [];
gdjs.NewSceneCode.GDstar_95particleObjects3= [];
gdjs.NewSceneCode.GDstar_95particleObjects4= [];
gdjs.NewSceneCode.GDstar_95particleObjects5= [];
gdjs.NewSceneCode.GDstar_95particleObjects6= [];
gdjs.NewSceneCode.GDstar_95particleObjects7= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects1= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects2= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects3= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects4= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects5= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects6= [];
gdjs.NewSceneCode.GDscreen_95fadeObjects7= [];
gdjs.NewSceneCode.GDui_95backgroundObjects1= [];
gdjs.NewSceneCode.GDui_95backgroundObjects2= [];
gdjs.NewSceneCode.GDui_95backgroundObjects3= [];
gdjs.NewSceneCode.GDui_95backgroundObjects4= [];
gdjs.NewSceneCode.GDui_95backgroundObjects5= [];
gdjs.NewSceneCode.GDui_95backgroundObjects6= [];
gdjs.NewSceneCode.GDui_95backgroundObjects7= [];
gdjs.NewSceneCode.GDmotionObjects1= [];
gdjs.NewSceneCode.GDmotionObjects2= [];
gdjs.NewSceneCode.GDmotionObjects3= [];
gdjs.NewSceneCode.GDmotionObjects4= [];
gdjs.NewSceneCode.GDmotionObjects5= [];
gdjs.NewSceneCode.GDmotionObjects6= [];
gdjs.NewSceneCode.GDmotionObjects7= [];

gdjs.NewSceneCode.conditionTrue_0 = {val:false};
gdjs.NewSceneCode.condition0IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition1IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition2IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition3IsTrue_0 = {val:false};
gdjs.NewSceneCode.conditionTrue_1 = {val:false};
gdjs.NewSceneCode.condition0IsTrue_1 = {val:false};
gdjs.NewSceneCode.condition1IsTrue_1 = {val:false};
gdjs.NewSceneCode.condition2IsTrue_1 = {val:false};
gdjs.NewSceneCode.condition3IsTrue_1 = {val:false};


gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595monObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595wedObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595satObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595weekObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595friObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595tueObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595sunObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595thurObjects4Objects = Hashtable.newFrom({"card_mon": gdjs.NewSceneCode.GDcard_95monObjects4, "card_wed": gdjs.NewSceneCode.GDcard_95wedObjects4, "card_sat": gdjs.NewSceneCode.GDcard_95satObjects4, "card_week": gdjs.NewSceneCode.GDcard_95weekObjects4, "card_fri": gdjs.NewSceneCode.GDcard_95friObjects4, "card_tue": gdjs.NewSceneCode.GDcard_95tueObjects4, "card_sun": gdjs.NewSceneCode.GDcard_95sunObjects4, "card_thur": gdjs.NewSceneCode.GDcard_95thurObjects4});gdjs.NewSceneCode.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.NewSceneCode.GDcard_95friObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95monObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95satObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95sunObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95thurObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95tueObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95wedObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95weekObjects4 */

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595monObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595wedObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595satObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595weekObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595friObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595tueObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595sunObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595thurObjects4Objects);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDcard_95friObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95monObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95satObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95sunObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95thurObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95tueObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95wedObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95weekObjects4 */
/* Reuse gdjs.NewSceneCode.GDposition_95placeholderObjects4 */
{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects4[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDposition_95placeholderObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDposition_95placeholderObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.NewSceneCode.eventsList1 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("card_fri"), gdjs.NewSceneCode.GDcard_95friObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_mon"), gdjs.NewSceneCode.GDcard_95monObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_sat"), gdjs.NewSceneCode.GDcard_95satObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_sun"), gdjs.NewSceneCode.GDcard_95sunObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_thur"), gdjs.NewSceneCode.GDcard_95thurObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_tue"), gdjs.NewSceneCode.GDcard_95tueObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_wed"), gdjs.NewSceneCode.GDcard_95wedObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_week"), gdjs.NewSceneCode.GDcard_95weekObjects4);

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95monObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95monObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95monObjects4[k] = gdjs.NewSceneCode.GDcard_95monObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95monObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95wedObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95wedObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95wedObjects4[k] = gdjs.NewSceneCode.GDcard_95wedObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95wedObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95satObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95satObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95satObjects4[k] = gdjs.NewSceneCode.GDcard_95satObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95satObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95weekObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95weekObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95weekObjects4[k] = gdjs.NewSceneCode.GDcard_95weekObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95weekObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95friObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95friObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95friObjects4[k] = gdjs.NewSceneCode.GDcard_95friObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95friObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95tueObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95tueObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95tueObjects4[k] = gdjs.NewSceneCode.GDcard_95tueObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95tueObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95sunObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95sunObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95sunObjects4[k] = gdjs.NewSceneCode.GDcard_95sunObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95sunObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95thurObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95thurObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95thurObjects4[k] = gdjs.NewSceneCode.GDcard_95thurObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95thurObjects4.length = k;}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDcard_95friObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95monObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95satObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95sunObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95thurObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95tueObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95wedObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95weekObjects4 */
gdjs.copyArray(gdjs.NewSceneCode.GDposition_95placeholderObjects3, gdjs.NewSceneCode.GDposition_95placeholderObjects4);

{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointX("")), (( gdjs.NewSceneCode.GDposition_95placeholderObjects4.length === 0 ) ? 0 :gdjs.NewSceneCode.GDposition_95placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
}
{ //Subevents
gdjs.NewSceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.NewSceneCode.eventsList2 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("position_placeholder"), gdjs.NewSceneCode.GDposition_95placeholderObjects2);

for(gdjs.NewSceneCode.forEachIndex3 = 0;gdjs.NewSceneCode.forEachIndex3 < gdjs.NewSceneCode.GDposition_95placeholderObjects2.length;++gdjs.NewSceneCode.forEachIndex3) {
gdjs.NewSceneCode.GDposition_95placeholderObjects3.length = 0;


gdjs.NewSceneCode.forEachTemporary3 = gdjs.NewSceneCode.GDposition_95placeholderObjects2[gdjs.NewSceneCode.forEachIndex3];
gdjs.NewSceneCode.GDposition_95placeholderObjects3.push(gdjs.NewSceneCode.forEachTemporary3);
if (true) {

{ //Subevents: 
gdjs.NewSceneCode.eventsList1(runtimeScene);} //Subevents end.
}
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("screen_fade"), gdjs.NewSceneCode.GDscreen_95fadeObjects1);
{for(var i = 0, len = gdjs.NewSceneCode.GDscreen_95fadeObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDscreen_95fadeObjects1[i].getBehavior("Tween").addObjectOpacityTween("fade_in", 0, "linear", 1000, true);
}
}}

}


};gdjs.NewSceneCode.eventsList3 = function(runtimeScene) {

{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595monObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595wedObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595satObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595weekObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595friObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595tueObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595sunObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595thurObjects2Objects = Hashtable.newFrom({"card_mon": gdjs.NewSceneCode.GDcard_95monObjects2, "card_wed": gdjs.NewSceneCode.GDcard_95wedObjects2, "card_sat": gdjs.NewSceneCode.GDcard_95satObjects2, "card_week": gdjs.NewSceneCode.GDcard_95weekObjects2, "card_fri": gdjs.NewSceneCode.GDcard_95friObjects2, "card_tue": gdjs.NewSceneCode.GDcard_95tueObjects2, "card_sun": gdjs.NewSceneCode.GDcard_95sunObjects2, "card_thur": gdjs.NewSceneCode.GDcard_95thurObjects2});gdjs.NewSceneCode.eventsList4 = function(runtimeScene) {

{



}


{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "show_cards");
}{runtimeScene.getVariables().getFromIndex(4).setString("show_cards");
}}

}


};gdjs.NewSceneCode.eventsList5 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.NewSceneCode.GDcard_95friObjects2, gdjs.NewSceneCode.GDcard_95friObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95monObjects2, gdjs.NewSceneCode.GDcard_95monObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95satObjects2, gdjs.NewSceneCode.GDcard_95satObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95sunObjects2, gdjs.NewSceneCode.GDcard_95sunObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95thurObjects2, gdjs.NewSceneCode.GDcard_95thurObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95tueObjects2, gdjs.NewSceneCode.GDcard_95tueObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95wedObjects2, gdjs.NewSceneCode.GDcard_95wedObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95weekObjects2, gdjs.NewSceneCode.GDcard_95weekObjects3);

{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects3.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false);
}
}}

}


{



}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.NewSceneCode.GDcard_95friObjects2, gdjs.NewSceneCode.GDcard_95friObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95monObjects2, gdjs.NewSceneCode.GDcard_95monObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95satObjects2, gdjs.NewSceneCode.GDcard_95satObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95sunObjects2, gdjs.NewSceneCode.GDcard_95sunObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95thurObjects2, gdjs.NewSceneCode.GDcard_95thurObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95tueObjects2, gdjs.NewSceneCode.GDcard_95tueObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95wedObjects2, gdjs.NewSceneCode.GDcard_95wedObjects3);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95weekObjects2, gdjs.NewSceneCode.GDcard_95weekObjects3);

{runtimeScene.getVariables().getFromIndex(2).setString((gdjs.RuntimeObject.getVariableString(((gdjs.NewSceneCode.GDcard_95thurObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95sunObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95tueObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95friObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95weekObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95satObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95wedObjects3.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95monObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.NewSceneCode.GDcard_95monObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95wedObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95satObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95weekObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95friObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95tueObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95sunObjects3[0].getVariables()) : gdjs.NewSceneCode.GDcard_95thurObjects3[0].getVariables()).get("id"))));
}
{ //Subevents
gdjs.NewSceneCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDcard_95friObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95monObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95satObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95sunObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95thurObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95tueObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95wedObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95weekObjects2 */
{runtimeScene.getVariables().getFromIndex(0).setString((gdjs.RuntimeObject.getVariableString(((gdjs.NewSceneCode.GDcard_95thurObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95sunObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95tueObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95friObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95weekObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95satObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95wedObjects2.length === 0 ) ? ((gdjs.NewSceneCode.GDcard_95monObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.NewSceneCode.GDcard_95monObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95wedObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95satObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95weekObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95friObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95tueObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95sunObjects2[0].getVariables()) : gdjs.NewSceneCode.GDcard_95thurObjects2[0].getVariables()).get("id"))));
}}

}


};gdjs.NewSceneCode.eventsList6 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("card_fri"), gdjs.NewSceneCode.GDcard_95friObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_mon"), gdjs.NewSceneCode.GDcard_95monObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_sat"), gdjs.NewSceneCode.GDcard_95satObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_sun"), gdjs.NewSceneCode.GDcard_95sunObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_thur"), gdjs.NewSceneCode.GDcard_95thurObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_tue"), gdjs.NewSceneCode.GDcard_95tueObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_wed"), gdjs.NewSceneCode.GDcard_95wedObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_week"), gdjs.NewSceneCode.GDcard_95weekObjects2);

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
gdjs.NewSceneCode.condition2IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
gdjs.NewSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595monObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595wedObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595satObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595weekObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595friObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595tueObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595sunObjects2ObjectsGDgdjs_46NewSceneCode_46GDcard_9595thurObjects2Objects, runtimeScene, true, false);
}if ( gdjs.NewSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95monObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95monObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95monObjects2[k] = gdjs.NewSceneCode.GDcard_95monObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95monObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95wedObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95wedObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95wedObjects2[k] = gdjs.NewSceneCode.GDcard_95wedObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95wedObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95satObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95satObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95satObjects2[k] = gdjs.NewSceneCode.GDcard_95satObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95satObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95weekObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95weekObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95weekObjects2[k] = gdjs.NewSceneCode.GDcard_95weekObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95weekObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95friObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95friObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95friObjects2[k] = gdjs.NewSceneCode.GDcard_95friObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95friObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95tueObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95tueObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95tueObjects2[k] = gdjs.NewSceneCode.GDcard_95tueObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95tueObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95sunObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95sunObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95sunObjects2[k] = gdjs.NewSceneCode.GDcard_95sunObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95sunObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95thurObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95thurObjects2[i].isCurrentAnimationName("back") ) {
        gdjs.NewSceneCode.condition2IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95thurObjects2[k] = gdjs.NewSceneCode.GDcard_95thurObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95thurObjects2.length = k;}}
}
if (gdjs.NewSceneCode.condition2IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/cockatrice_playcard.mp3", false, 100, 1);
}
{ //Subevents
gdjs.NewSceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.NewSceneCode.eventsList7 = function(runtimeScene) {

{


{
/* Reuse gdjs.NewSceneCode.GDcard_95friObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95monObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95satObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95sunObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95thurObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95tueObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95wedObjects2 */
/* Reuse gdjs.NewSceneCode.GDcard_95weekObjects2 */
{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects2[i].setAnimationName("front");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false);
}
}}

}


};gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595monObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595wedObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595satObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595weekObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595friObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595tueObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595sunObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595thurObjects4Objects = Hashtable.newFrom({"card_mon": gdjs.NewSceneCode.GDcard_95monObjects4, "card_wed": gdjs.NewSceneCode.GDcard_95wedObjects4, "card_sat": gdjs.NewSceneCode.GDcard_95satObjects4, "card_week": gdjs.NewSceneCode.GDcard_95weekObjects4, "card_fri": gdjs.NewSceneCode.GDcard_95friObjects4, "card_tue": gdjs.NewSceneCode.GDcard_95tueObjects4, "card_sun": gdjs.NewSceneCode.GDcard_95sunObjects4, "card_thur": gdjs.NewSceneCode.GDcard_95thurObjects4});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDstar_9595particleObjects6Objects = Hashtable.newFrom({"star_particle": gdjs.NewSceneCode.GDstar_95particleObjects6});gdjs.NewSceneCode.eventsList8 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.NewSceneCode.GDcard_95friObjects5, gdjs.NewSceneCode.GDcard_95friObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95monObjects5, gdjs.NewSceneCode.GDcard_95monObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95satObjects5, gdjs.NewSceneCode.GDcard_95satObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95sunObjects5, gdjs.NewSceneCode.GDcard_95sunObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95thurObjects5, gdjs.NewSceneCode.GDcard_95thurObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95tueObjects5, gdjs.NewSceneCode.GDcard_95tueObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95wedObjects5, gdjs.NewSceneCode.GDcard_95wedObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95weekObjects5, gdjs.NewSceneCode.GDcard_95weekObjects6);

gdjs.NewSceneCode.GDstar_95particleObjects6.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/cuckoo.wav", false, 100, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDstar_9595particleObjects6Objects, (( gdjs.NewSceneCode.GDcard_95thurObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95sunObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95tueObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95friObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95weekObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95satObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95wedObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95monObjects6.length === 0 ) ? 0 :gdjs.NewSceneCode.GDcard_95monObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95wedObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95satObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95weekObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95friObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95tueObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95sunObjects6[0].getPointX("")) :gdjs.NewSceneCode.GDcard_95thurObjects6[0].getPointX("")), (( gdjs.NewSceneCode.GDcard_95thurObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95sunObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95tueObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95friObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95weekObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95satObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95wedObjects6.length === 0 ) ? (( gdjs.NewSceneCode.GDcard_95monObjects6.length === 0 ) ? 0 :gdjs.NewSceneCode.GDcard_95monObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95wedObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95satObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95weekObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95friObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95tueObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95sunObjects6[0].getPointY("")) :gdjs.NewSceneCode.GDcard_95thurObjects6[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDstar_95particleObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDstar_95particleObjects6[i].setZOrder(100);
}
}}

}


{



}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition0IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7840532);
}
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.NewSceneCode.GDcard_95friObjects5, gdjs.NewSceneCode.GDcard_95friObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95monObjects5, gdjs.NewSceneCode.GDcard_95monObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95satObjects5, gdjs.NewSceneCode.GDcard_95satObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95sunObjects5, gdjs.NewSceneCode.GDcard_95sunObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95thurObjects5, gdjs.NewSceneCode.GDcard_95thurObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95tueObjects5, gdjs.NewSceneCode.GDcard_95tueObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95wedObjects5, gdjs.NewSceneCode.GDcard_95wedObjects6);

gdjs.copyArray(gdjs.NewSceneCode.GDcard_95weekObjects5, gdjs.NewSceneCode.GDcard_95weekObjects6);

{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects6.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true);
}
}}

}


};gdjs.NewSceneCode.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.NewSceneCode.GDcard_95friObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95monObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95satObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95sunObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95thurObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95tueObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95wedObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95weekObjects4 */

gdjs.NewSceneCode.forEachTotalCount5 = 0;
gdjs.NewSceneCode.forEachObjects5.length = 0;
gdjs.NewSceneCode.forEachCount0_5 = gdjs.NewSceneCode.GDcard_95monObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount0_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95monObjects4);
gdjs.NewSceneCode.forEachCount1_5 = gdjs.NewSceneCode.GDcard_95wedObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount1_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95wedObjects4);
gdjs.NewSceneCode.forEachCount2_5 = gdjs.NewSceneCode.GDcard_95satObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount2_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95satObjects4);
gdjs.NewSceneCode.forEachCount3_5 = gdjs.NewSceneCode.GDcard_95weekObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount3_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95weekObjects4);
gdjs.NewSceneCode.forEachCount4_5 = gdjs.NewSceneCode.GDcard_95friObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount4_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95friObjects4);
gdjs.NewSceneCode.forEachCount5_5 = gdjs.NewSceneCode.GDcard_95tueObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount5_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95tueObjects4);
gdjs.NewSceneCode.forEachCount6_5 = gdjs.NewSceneCode.GDcard_95sunObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount6_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95sunObjects4);
gdjs.NewSceneCode.forEachCount7_5 = gdjs.NewSceneCode.GDcard_95thurObjects4.length;
gdjs.NewSceneCode.forEachTotalCount5 += gdjs.NewSceneCode.forEachCount7_5;
gdjs.NewSceneCode.forEachObjects5.push.apply(gdjs.NewSceneCode.forEachObjects5,gdjs.NewSceneCode.GDcard_95thurObjects4);
for(gdjs.NewSceneCode.forEachIndex5 = 0;gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachTotalCount5;++gdjs.NewSceneCode.forEachIndex5) {
gdjs.NewSceneCode.GDcard_95friObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95monObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95satObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95sunObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95thurObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95tueObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95wedObjects5.length = 0;

gdjs.NewSceneCode.GDcard_95weekObjects5.length = 0;


if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5) {
    gdjs.NewSceneCode.GDcard_95monObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5) {
    gdjs.NewSceneCode.GDcard_95wedObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5) {
    gdjs.NewSceneCode.GDcard_95satObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5+gdjs.NewSceneCode.forEachCount3_5) {
    gdjs.NewSceneCode.GDcard_95weekObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5+gdjs.NewSceneCode.forEachCount3_5+gdjs.NewSceneCode.forEachCount4_5) {
    gdjs.NewSceneCode.GDcard_95friObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5+gdjs.NewSceneCode.forEachCount3_5+gdjs.NewSceneCode.forEachCount4_5+gdjs.NewSceneCode.forEachCount5_5) {
    gdjs.NewSceneCode.GDcard_95tueObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5+gdjs.NewSceneCode.forEachCount3_5+gdjs.NewSceneCode.forEachCount4_5+gdjs.NewSceneCode.forEachCount5_5+gdjs.NewSceneCode.forEachCount6_5) {
    gdjs.NewSceneCode.GDcard_95sunObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
else if (gdjs.NewSceneCode.forEachIndex5 < gdjs.NewSceneCode.forEachCount0_5+gdjs.NewSceneCode.forEachCount1_5+gdjs.NewSceneCode.forEachCount2_5+gdjs.NewSceneCode.forEachCount3_5+gdjs.NewSceneCode.forEachCount4_5+gdjs.NewSceneCode.forEachCount5_5+gdjs.NewSceneCode.forEachCount6_5+gdjs.NewSceneCode.forEachCount7_5) {
    gdjs.NewSceneCode.GDcard_95thurObjects5.push(gdjs.NewSceneCode.forEachObjects5[gdjs.NewSceneCode.forEachIndex5]);
}
if (true) {

{ //Subevents: 
gdjs.NewSceneCode.eventsList8(runtimeScene);} //Subevents end.
}
}

}


};gdjs.NewSceneCode.eventsList10 = function(runtimeScene) {

{

/* Reuse gdjs.NewSceneCode.GDcard_95friObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95monObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95satObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95sunObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95thurObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95tueObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95wedObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95weekObjects4 */

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95monObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95monObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95monObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95monObjects4[k] = gdjs.NewSceneCode.GDcard_95monObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95monObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95wedObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95wedObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95wedObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95wedObjects4[k] = gdjs.NewSceneCode.GDcard_95wedObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95wedObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95satObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95satObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95satObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95satObjects4[k] = gdjs.NewSceneCode.GDcard_95satObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95satObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95weekObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95weekObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95weekObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95weekObjects4[k] = gdjs.NewSceneCode.GDcard_95weekObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95weekObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95friObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95friObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95friObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95friObjects4[k] = gdjs.NewSceneCode.GDcard_95friObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95friObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95tueObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95tueObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95tueObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95tueObjects4[k] = gdjs.NewSceneCode.GDcard_95tueObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95tueObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95sunObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95sunObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95sunObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95sunObjects4[k] = gdjs.NewSceneCode.GDcard_95sunObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95sunObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95thurObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95thurObjects4[i].getVariableString(gdjs.NewSceneCode.GDcard_95thurObjects4[i].getVariables().get("id")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95thurObjects4[k] = gdjs.NewSceneCode.GDcard_95thurObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95thurObjects4.length = k;}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.NewSceneCode.eventsList11 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("card_fri"), gdjs.NewSceneCode.GDcard_95friObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_mon"), gdjs.NewSceneCode.GDcard_95monObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_sat"), gdjs.NewSceneCode.GDcard_95satObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_sun"), gdjs.NewSceneCode.GDcard_95sunObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_thur"), gdjs.NewSceneCode.GDcard_95thurObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_tue"), gdjs.NewSceneCode.GDcard_95tueObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_wed"), gdjs.NewSceneCode.GDcard_95wedObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_week"), gdjs.NewSceneCode.GDcard_95weekObjects4);
{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595monObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595wedObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595satObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595weekObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595friObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595tueObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595sunObjects4ObjectsGDgdjs_46NewSceneCode_46GDcard_9595thurObjects4Objects);
}
{ //Subevents
gdjs.NewSceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.NewSceneCode.eventsList12 = function(runtimeScene) {

{



}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2));
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("pairs"), gdjs.NewSceneCode.GDpairsObjects4);
{runtimeScene.getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.NewSceneCode.GDpairsObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDpairsObjects4[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDpairsObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDpairsObjects4[i].getBehavior("Tween").addObjectColorTween("flash", "255;251;251", "easeInOutQuad", 250, false);
}
}
{ //Subevents
gdjs.NewSceneCode.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("card_fri"), gdjs.NewSceneCode.GDcard_95friObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_mon"), gdjs.NewSceneCode.GDcard_95monObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_sat"), gdjs.NewSceneCode.GDcard_95satObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_sun"), gdjs.NewSceneCode.GDcard_95sunObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_thur"), gdjs.NewSceneCode.GDcard_95thurObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_tue"), gdjs.NewSceneCode.GDcard_95tueObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_wed"), gdjs.NewSceneCode.GDcard_95wedObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_week"), gdjs.NewSceneCode.GDcard_95weekObjects4);

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95monObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95monObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95monObjects4[k] = gdjs.NewSceneCode.GDcard_95monObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95monObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95wedObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95wedObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95wedObjects4[k] = gdjs.NewSceneCode.GDcard_95wedObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95wedObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95satObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95satObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95satObjects4[k] = gdjs.NewSceneCode.GDcard_95satObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95satObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95weekObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95weekObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95weekObjects4[k] = gdjs.NewSceneCode.GDcard_95weekObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95weekObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95friObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95friObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95friObjects4[k] = gdjs.NewSceneCode.GDcard_95friObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95friObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95tueObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95tueObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95tueObjects4[k] = gdjs.NewSceneCode.GDcard_95tueObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95tueObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95sunObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95sunObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95sunObjects4[k] = gdjs.NewSceneCode.GDcard_95sunObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95sunObjects4.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95thurObjects4.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95thurObjects4[i].isCurrentAnimationName("front") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95thurObjects4[k] = gdjs.NewSceneCode.GDcard_95thurObjects4[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95thurObjects4.length = k;}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition1IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7841780);
}
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDcard_95friObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95monObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95satObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95sunObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95thurObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95tueObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95wedObjects4 */
/* Reuse gdjs.NewSceneCode.GDcard_95weekObjects4 */
{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects4.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false);
}
}}

}


{



}


{


{
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(1).setNumber(0);
}}

}


};gdjs.NewSceneCode.eventsList13 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.NewSceneCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


{
{runtimeScene.getVariables().getFromIndex(4).setString("player_turn");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}}

}


};gdjs.NewSceneCode.eventsList14 = function(runtimeScene) {

{


{
/* Reuse gdjs.NewSceneCode.GDcard_95friObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95monObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95satObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95sunObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95thurObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95tueObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95wedObjects1 */
/* Reuse gdjs.NewSceneCode.GDcard_95weekObjects1 */
{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects1[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDcard_95monObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95monObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95wedObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95wedObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95satObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95satObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95weekObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95weekObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95friObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95friObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95tueObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95tueObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95sunObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95sunObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
for(var i = 0, len = gdjs.NewSceneCode.GDcard_95thurObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDcard_95thurObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false);
}
}}

}


};gdjs.NewSceneCode.eventsList15 = function(runtimeScene) {

{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4)) == "player_turn";
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("card_fri"), gdjs.NewSceneCode.GDcard_95friObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_mon"), gdjs.NewSceneCode.GDcard_95monObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_sat"), gdjs.NewSceneCode.GDcard_95satObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_sun"), gdjs.NewSceneCode.GDcard_95sunObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_thur"), gdjs.NewSceneCode.GDcard_95thurObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_tue"), gdjs.NewSceneCode.GDcard_95tueObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_wed"), gdjs.NewSceneCode.GDcard_95wedObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_week"), gdjs.NewSceneCode.GDcard_95weekObjects2);

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95monObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95monObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95monObjects2[k] = gdjs.NewSceneCode.GDcard_95monObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95monObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95wedObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95wedObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95wedObjects2[k] = gdjs.NewSceneCode.GDcard_95wedObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95wedObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95satObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95satObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95satObjects2[k] = gdjs.NewSceneCode.GDcard_95satObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95satObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95weekObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95weekObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95weekObjects2[k] = gdjs.NewSceneCode.GDcard_95weekObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95weekObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95friObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95friObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95friObjects2[k] = gdjs.NewSceneCode.GDcard_95friObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95friObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95tueObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95tueObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95tueObjects2[k] = gdjs.NewSceneCode.GDcard_95tueObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95tueObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95sunObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95sunObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95sunObjects2[k] = gdjs.NewSceneCode.GDcard_95sunObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95sunObjects2.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95thurObjects2.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95thurObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95thurObjects2[k] = gdjs.NewSceneCode.GDcard_95thurObjects2[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95thurObjects2.length = k;}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.5, "show_cards");
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition1IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7835092);
}
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("card_fri"), gdjs.NewSceneCode.GDcard_95friObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_mon"), gdjs.NewSceneCode.GDcard_95monObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_sat"), gdjs.NewSceneCode.GDcard_95satObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_sun"), gdjs.NewSceneCode.GDcard_95sunObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_thur"), gdjs.NewSceneCode.GDcard_95thurObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_tue"), gdjs.NewSceneCode.GDcard_95tueObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_wed"), gdjs.NewSceneCode.GDcard_95wedObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_week"), gdjs.NewSceneCode.GDcard_95weekObjects1);

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95monObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95monObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95monObjects1[k] = gdjs.NewSceneCode.GDcard_95monObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95monObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95wedObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95wedObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95wedObjects1[k] = gdjs.NewSceneCode.GDcard_95wedObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95wedObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95satObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95satObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95satObjects1[k] = gdjs.NewSceneCode.GDcard_95satObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95satObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95weekObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95weekObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95weekObjects1[k] = gdjs.NewSceneCode.GDcard_95weekObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95weekObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95friObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95friObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95friObjects1[k] = gdjs.NewSceneCode.GDcard_95friObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95friObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95tueObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95tueObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95tueObjects1[k] = gdjs.NewSceneCode.GDcard_95tueObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95tueObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95sunObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95sunObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95sunObjects1[k] = gdjs.NewSceneCode.GDcard_95sunObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95sunObjects1.length = k;for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDcard_95thurObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDcard_95thurObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDcard_95thurObjects1[k] = gdjs.NewSceneCode.GDcard_95thurObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDcard_95thurObjects1.length = k;}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition1IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7844708);
}
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.NewSceneCode.GDbuttonObjects1});gdjs.NewSceneCode.eventsList16 = function(runtimeScene) {

{



}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition0IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7847348);
}
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDbuttonObjects1 */
{for(var i = 0, len = gdjs.NewSceneCode.GDbuttonObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDbuttonObjects1[i].getBehavior("Tween").addObjectColorTween("shine", "150;150;150", "easeFromTo", 500, false);
}
}}

}


};gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.NewSceneCode.GDbuttonObjects1});gdjs.NewSceneCode.eventsList17 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.NewSceneCode.GDbuttonObjects1, gdjs.NewSceneCode.GDbuttonObjects2);

{for(var i = 0, len = gdjs.NewSceneCode.GDbuttonObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDbuttonObjects2[i].getBehavior("Tween").addObjectColorTween("shine", "255;255;255", "easeFromTo", 500, false);
}
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/pop.ogg", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "NewScene", false);
}}

}


};gdjs.NewSceneCode.eventsList18 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("pairs"), gdjs.NewSceneCode.GDpairsObjects2);
{for(var i = 0, len = gdjs.NewSceneCode.GDpairsObjects2.length ;i < len;++i) {
    gdjs.NewSceneCode.GDpairsObjects2[i].setString("Pairs: " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)));
}
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "UI");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
{}}

}


};gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595monObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595wedObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595satObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595weekObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595friObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595tueObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595sunObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595thurObjects1Objects = Hashtable.newFrom({"card_mon": gdjs.NewSceneCode.GDcard_95monObjects1, "card_wed": gdjs.NewSceneCode.GDcard_95wedObjects1, "card_sat": gdjs.NewSceneCode.GDcard_95satObjects1, "card_week": gdjs.NewSceneCode.GDcard_95weekObjects1, "card_fri": gdjs.NewSceneCode.GDcard_95friObjects1, "card_tue": gdjs.NewSceneCode.GDcard_95tueObjects1, "card_sun": gdjs.NewSceneCode.GDcard_95sunObjects1, "card_thur": gdjs.NewSceneCode.GDcard_95thurObjects1});gdjs.NewSceneCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("card_fri"), gdjs.NewSceneCode.GDcard_95friObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_mon"), gdjs.NewSceneCode.GDcard_95monObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_sat"), gdjs.NewSceneCode.GDcard_95satObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_sun"), gdjs.NewSceneCode.GDcard_95sunObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_thur"), gdjs.NewSceneCode.GDcard_95thurObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_tue"), gdjs.NewSceneCode.GDcard_95tueObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_wed"), gdjs.NewSceneCode.GDcard_95wedObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_week"), gdjs.NewSceneCode.GDcard_95weekObjects1);

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDcard_9595monObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595wedObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595satObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595weekObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595friObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595tueObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595sunObjects1ObjectsGDgdjs_46NewSceneCode_46GDcard_9595thurObjects1Objects) <= 0;
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.NewSceneCode.conditionTrue_1 = gdjs.NewSceneCode.condition1IsTrue_0;
gdjs.NewSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7852348);
}
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/Rise.ogg", false, 100, 1);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "UI");
}}

}


};gdjs.NewSceneCode.eventsList20 = function(runtimeScene) {

{


gdjs.NewSceneCode.eventsList3(runtimeScene);
}


{


gdjs.NewSceneCode.eventsList15(runtimeScene);
}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.NewSceneCode.GDbuttonObjects1);

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDbuttonObjects1Objects, runtimeScene, true, true);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.NewSceneCode.GDbuttonObjects1);

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDbuttonObjects1Objects, runtimeScene, true, false);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.NewSceneCode.eventsList17(runtimeScene);} //End of subevents
}

}


{


gdjs.NewSceneCode.eventsList18(runtimeScene);
}


{


gdjs.NewSceneCode.eventsList19(runtimeScene);
}


};

gdjs.NewSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.NewSceneCode.GDcard_95wedObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95wedObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95wedObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95wedObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95wedObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95wedObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95wedObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95satObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95satObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95satObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95satObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95satObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95satObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95satObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95weekObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95weekObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95weekObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95weekObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95weekObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95weekObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95weekObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95friObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95friObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95friObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95friObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95friObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95friObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95friObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95tueObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95tueObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95tueObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95tueObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95tueObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95tueObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95tueObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95sunObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95sunObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95sunObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95sunObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95sunObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95sunObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95sunObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95thurObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95thurObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95thurObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95thurObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95thurObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95thurObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95thurObjects7.length = 0;
gdjs.NewSceneCode.GDcard_95monObjects1.length = 0;
gdjs.NewSceneCode.GDcard_95monObjects2.length = 0;
gdjs.NewSceneCode.GDcard_95monObjects3.length = 0;
gdjs.NewSceneCode.GDcard_95monObjects4.length = 0;
gdjs.NewSceneCode.GDcard_95monObjects5.length = 0;
gdjs.NewSceneCode.GDcard_95monObjects6.length = 0;
gdjs.NewSceneCode.GDcard_95monObjects7.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects1.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects2.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects3.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects4.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects5.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects6.length = 0;
gdjs.NewSceneCode.GDposition_95placeholderObjects7.length = 0;
gdjs.NewSceneCode.GDbuttonObjects1.length = 0;
gdjs.NewSceneCode.GDbuttonObjects2.length = 0;
gdjs.NewSceneCode.GDbuttonObjects3.length = 0;
gdjs.NewSceneCode.GDbuttonObjects4.length = 0;
gdjs.NewSceneCode.GDbuttonObjects5.length = 0;
gdjs.NewSceneCode.GDbuttonObjects6.length = 0;
gdjs.NewSceneCode.GDbuttonObjects7.length = 0;
gdjs.NewSceneCode.GDboardObjects1.length = 0;
gdjs.NewSceneCode.GDboardObjects2.length = 0;
gdjs.NewSceneCode.GDboardObjects3.length = 0;
gdjs.NewSceneCode.GDboardObjects4.length = 0;
gdjs.NewSceneCode.GDboardObjects5.length = 0;
gdjs.NewSceneCode.GDboardObjects6.length = 0;
gdjs.NewSceneCode.GDboardObjects7.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects1.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects2.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects3.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects4.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects5.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects6.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects7.length = 0;
gdjs.NewSceneCode.GDpairsObjects1.length = 0;
gdjs.NewSceneCode.GDpairsObjects2.length = 0;
gdjs.NewSceneCode.GDpairsObjects3.length = 0;
gdjs.NewSceneCode.GDpairsObjects4.length = 0;
gdjs.NewSceneCode.GDpairsObjects5.length = 0;
gdjs.NewSceneCode.GDpairsObjects6.length = 0;
gdjs.NewSceneCode.GDpairsObjects7.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects1.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects2.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects3.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects4.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects5.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects6.length = 0;
gdjs.NewSceneCode.GDstar_95particleObjects7.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects1.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects2.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects3.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects4.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects5.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects6.length = 0;
gdjs.NewSceneCode.GDscreen_95fadeObjects7.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects1.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects2.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects3.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects4.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects5.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects6.length = 0;
gdjs.NewSceneCode.GDui_95backgroundObjects7.length = 0;
gdjs.NewSceneCode.GDmotionObjects1.length = 0;
gdjs.NewSceneCode.GDmotionObjects2.length = 0;
gdjs.NewSceneCode.GDmotionObjects3.length = 0;
gdjs.NewSceneCode.GDmotionObjects4.length = 0;
gdjs.NewSceneCode.GDmotionObjects5.length = 0;
gdjs.NewSceneCode.GDmotionObjects6.length = 0;
gdjs.NewSceneCode.GDmotionObjects7.length = 0;

gdjs.NewSceneCode.eventsList20(runtimeScene);
return;

}

gdjs['NewSceneCode'] = gdjs.NewSceneCode;
